<template>
  <div class="hello">
    <ul class="list-group list-group-flush">
      <li
        v-for="item in movieslist"
        :key="item.message"
        class="list-group-item"
      >
        <img
          :src="`https://image.tmdb.org/t/p/w500/${item.poster_path}`"
          style="height: 35px; width: 45px"
        />
        {{ item.original_title }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      movieslist: {},
    };
  },
  props: {
    apikey: String,
    movieitem: String,
  },
  mounted() {
    axios
      .get(
        "https://api.themoviedb.org/3/movie/" +
          this.movieitem +
          "?api_key=" +
          this.apikey
      )
      .then((response) => {
        this.movieslist = response.data.results;
      });
  },
};
</script>
