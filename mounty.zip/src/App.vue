<template>
  <div id="app">
    <h2>The Movie DataBase</h2>
    <div class="row">
      <div class="col-sm-6">
        <div class="card" style="margin-left: 30px">
          <div class="card-header">Top Rated Movies</div>
          <ListMovies
            apikey="ef342afd9c205151529852466e2432d2"
            movieitem="top_rated"
          />
        </div>
      </div>
      <div class="col-sm-6">
        <div class="card" style="margin-right: 30px">
          <div class="card-header">UpComing Movies</div>
          <ListMovies
            apikey="ef342afd9c205151529852466e2432d2"
            movieitem="upcoming"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ListMovies from "./components/ListMovies.vue";
export default {
  name: "App",
  components: {
    ListMovies,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
